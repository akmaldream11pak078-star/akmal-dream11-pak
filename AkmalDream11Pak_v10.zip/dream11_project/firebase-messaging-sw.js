// firebase-messaging-sw.js — handles PUSH notifications when app is in background/closed
// Must stay at the site root (same level as index.html)

importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyD0Z9cJeKbaP1TGGt-o7S769w08fgL59Sk",
  authDomain: "akmaldream11pak.firebaseapp.com",
  projectId: "akmaldream11pak",
  storageBucket: "akmaldream11pak.firebasestorage.app",
  messagingSenderId: "958695333536",
  appId: "1:958695333536:web:baf0f21406db5b8ba033c5"
});

const messaging = firebase.messaging();

// Background message handler — shows a system notification
messaging.onBackgroundMessage((payload) => {
  const title = payload.notification?.title || 'PredictionPro';
  const options = {
    body: payload.notification?.body || 'New update available',
    icon: './icons/icon-192.png',
    badge: './icons/icon-192.png',
    data: payload.data || {}
  };
  self.registration.showNotification(title, options);
});

// Open/focus the app when notification is tapped
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window' }).then((clientsArr) => {
      const url = event.notification.data?.url || './';
      const existing = clientsArr.find((c) => c.url.includes(self.location.origin));
      if (existing) return existing.focus();
      return self.clients.openWindow(url);
    })
  );
});
