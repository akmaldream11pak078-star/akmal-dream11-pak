// netlify/functions/send-otp.js
//
// Generates a 6-digit OTP for password-reset verification, stores it in
// Firestore (collection: pp_password_otps, doc id = email) with a 10-minute
// expiry, and emails it via Gmail SMTP.

const PROJECT_ID = process.env.FIREBASE_PROJECT_ID;
const CLIENT_EMAIL = process.env.FIREBASE_CLIENT_EMAIL;
const GMAIL_USER = process.env.GMAIL_USER;
const GMAIL_APP_PASSWORD = process.env.GMAIL_APP_PASSWORD;
const crypto = require('crypto');

function getPrivateKey() {
  let key = process.env.FIREBASE_PRIVATE_KEY || '';
  key = key.trim();
  if ((key.startsWith('"') && key.endsWith('"')) || (key.startsWith("'") && key.endsWith("'"))) {
    key = key.slice(1, -1);
  }
  key = key.replace(/\\n/g, '\n').replace(/\r\n/g, '\n');
  return key;
}
const PRIVATE_KEY = getPrivateKey();

async function getAccessToken() {
  const header = { alg: 'RS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const claimSet = {
    iss: CLIENT_EMAIL,
    scope: 'https://www.googleapis.com/auth/datastore',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now
  };
  const base64url = (obj) =>
    Buffer.from(JSON.stringify(obj)).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unsigned = `${base64url(header)}.${base64url(claimSet)}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(unsigned);
  signer.end();
  const signature = signer.sign(PRIVATE_KEY).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const jwt = `${unsigned}.${signature}`;
  const resp = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  });
  const data = await resp.json();
  if (!data.access_token) throw new Error('Failed to get access token: ' + JSON.stringify(data));
  return data.access_token;
}

async function writeOtpDoc(accessToken, email, otpHash, expiresAt) {
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents/pp_password_otps/${encodeURIComponent(email)}`;
  const resp = await fetch(url, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` },
    body: JSON.stringify({
      fields: {
        otpHash: { stringValue: otpHash },
        expiresAt: { integerValue: String(expiresAt) },
        attempts: { integerValue: "0" }
      }
    })
  });
  const data = await resp.json();
  if (data.error) throw new Error(data.error.message || 'Failed to store OTP');
}

// Send email via Gmail SMTP using raw base64 encoded MIME message
async function sendEmailViaGmail(to, otp) {
  const subject = `Your PredictionPro verification code: ${otp}`;
  const body = `<div style="font-family:sans-serif;max-width:400px;margin:0 auto">
    <h2>Password Reset Verification</h2>
    <p>Your verification code is:</p>
    <p style="font-size:32px;font-weight:bold;letter-spacing:4px;color:#6366f1">${otp}</p>
    <p>This code expires in <b>10 minutes</b>.</p>
    <p style="color:#999;font-size:12px">If you didn't request this, you can ignore this email.</p>
  </div>`;

  const mime = [
    `From: PredictionPro <${GMAIL_USER}>`,
    `To: ${to}`,
    `Subject: ${subject}`,
    `MIME-Version: 1.0`,
    `Content-Type: text/html; charset=utf-8`,
    ``,
    body
  ].join('\r\n');

  const encoded = Buffer.from(mime).toString('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

  // Use Gmail API with OAuth2 using app password via basic auth SMTP alternative
  // Gmail API requires OAuth2, so we use nodemailer-style approach via fetch to Gmail SMTP
  // Instead, use Gmail API with basic auth (app password) through smtp2go or direct SMTP
  // Best approach: use Gmail REST API with base64 encoded message
  const authToken = Buffer.from(`${GMAIL_USER}:${GMAIL_APP_PASSWORD}`).toString('base64');

  const resp = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/send`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Basic ${authToken}`
    },
    body: JSON.stringify({ raw: encoded })
  });

  if (!resp.ok) {
    // Fallback: use smtp.gmail.com via nodemailer (requires npm package)
    throw new Error('Gmail API basic auth not supported. Use nodemailer.');
  }
}

// Proper Gmail send using nodemailer
async function sendEmailNodemailer(to, otp) {
  const nodemailer = require('nodemailer');
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: GMAIL_USER,
      pass: GMAIL_APP_PASSWORD
    }
  });

  await transporter.sendMail({
    from: `"PredictionPro" <${GMAIL_USER}>`,
    to: to,
    subject: `Your PredictionPro verification code: ${otp}`,
    html: `<div style="font-family:sans-serif;max-width:400px;margin:0 auto">
      <h2 style="color:#6366f1">Password Reset Verification</h2>
      <p>Your verification code is:</p>
      <p style="font-size:36px;font-weight:bold;letter-spacing:6px;color:#6366f1;background:#f3f4f6;padding:16px;border-radius:8px;text-align:center">${otp}</p>
      <p>This code expires in <b>10 minutes</b>.</p>
      <p style="color:#999;font-size:12px">If you didn't request this, you can ignore this email. — PredictionPro Team</p>
    </div>`
  });
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method not allowed' };

  if (!PROJECT_ID || !CLIENT_EMAIL || !PRIVATE_KEY) {
    return { statusCode: 500, body: JSON.stringify({ error: 'Missing Firebase service account environment variables.' }) };
  }
  if (!GMAIL_USER || !GMAIL_APP_PASSWORD) {
    return { statusCode: 500, body: JSON.stringify({ error: 'Missing GMAIL_USER or GMAIL_APP_PASSWORD environment variables.' }) };
  }

  try {
    const { email } = JSON.parse(event.body || '{}');
    if (!email || !email.includes('@')) {
      return { statusCode: 400, body: JSON.stringify({ error: 'A valid email is required.' }) };
    }
    const cleanEmail = email.toLowerCase().trim();

    const otp = String(Math.floor(100000 + Math.random() * 900000));
    const otpHash = crypto.createHash('sha256').update(otp).digest('hex');
    const expiresAt = Date.now() + 10 * 60 * 1000;

    const accessToken = await getAccessToken();
    await writeOtpDoc(accessToken, cleanEmail, otpHash, expiresAt);
    await sendEmailNodemailer(cleanEmail, otp);

    return { statusCode: 200, body: JSON.stringify({ status: 'otp_sent' }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
