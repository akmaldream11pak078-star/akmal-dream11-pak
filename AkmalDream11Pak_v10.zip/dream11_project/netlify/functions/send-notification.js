// netlify/functions/send-notification.js
//
// This function runs on Netlify's server (never in the browser).
// It uses the Firebase service account to get an OAuth token, then
// calls the FCM v1 API to push a notification to every saved device token.
//
// The service account credentials are read from environment variables
// (set in Netlify dashboard → Site settings → Environment variables),
// NOT hardcoded here, so they never appear in any file that gets deployed
// or viewed in browser dev tools.

const crypto = require('crypto');

const PROJECT_ID = process.env.FIREBASE_PROJECT_ID;
const CLIENT_EMAIL = process.env.FIREBASE_CLIENT_EMAIL;

function getPrivateKey() {
  let key = process.env.FIREBASE_PRIVATE_KEY || '';
  // Strip surrounding quotes if Netlify stored them literally
  key = key.trim();
  if (
    (key.startsWith('"') && key.endsWith('"')) ||
    (key.startsWith("'") && key.endsWith("'"))
  ) {
    key = key.slice(1, -1);
  }
  // Convert literal \n sequences into real newlines
  key = key.replace(/\\n/g, '\n');
  // Normalize Windows-style line endings just in case
  key = key.replace(/\r\n/g, '\n');
  return key;
}

const PRIVATE_KEY = getPrivateKey();

// Build and sign a JWT, then exchange it for a short-lived OAuth access token
async function getAccessToken() {
  const header = { alg: 'RS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const claimSet = {
    iss: CLIENT_EMAIL,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now
  };

  const base64url = (obj) =>
    Buffer.from(JSON.stringify(obj)).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

  const unsigned = `${base64url(header)}.${base64url(claimSet)}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(unsigned);
  signer.end();
  const signature = signer.sign(PRIVATE_KEY).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

  const jwt = `${unsigned}.${signature}`;

  const resp = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  });

  const data = await resp.json();
  if (!data.access_token) {
    throw new Error('Failed to get access token: ' + JSON.stringify(data));
  }
  return data.access_token;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  if (!PROJECT_ID || !CLIENT_EMAIL || !PRIVATE_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Missing Firebase service account environment variables on the server.' })
    };
  }

  if (!PRIVATE_KEY.includes('BEGIN PRIVATE KEY') || !PRIVATE_KEY.includes('END PRIVATE KEY')) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: 'FIREBASE_PRIVATE_KEY does not look like a valid PEM key (missing BEGIN/END markers). Check the Netlify environment variable value.',
        keyLength: PRIVATE_KEY.length,
        keyPreview: PRIVATE_KEY.substring(0, 40)
      })
    };
  }

  try {
    const { title, body, tokens } = JSON.parse(event.body || '{}');

    if (!title || !body || !Array.isArray(tokens) || tokens.length === 0) {
      return { statusCode: 400, body: JSON.stringify({ error: 'title, body, and a non-empty tokens array are required.' }) };
    }

    const accessToken = await getAccessToken();

    let successCount = 0;
    let failCount = 0;

    for (const token of tokens) {
      try {
        const resp = await fetch(
          `https://fcm.googleapis.com/v1/projects/${PROJECT_ID}/messages:send`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${accessToken}`
            },
            body: JSON.stringify({
              message: {
                token,
                notification: { title, body },
                webpush: {
                  notification: { icon: '/icons/icon-192.png' },
                  fcm_options: { link: '/' }
                }
              }
            })
          }
        );
        if (resp.ok) successCount++;
        else failCount++;
      } catch (e) {
        failCount++;
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ successCount, failCount, total: tokens.length })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
