// netlify/functions/wallet.js
//
// All wallet-balance-changing operations (deposit submission, withdrawal
// submission/hold, and admin approve/reject of both) now happen HERE,
// server-side, instead of in the browser.
//
// Why: balance was previously read, modified, and written straight from
// client-side JavaScript. Anyone with browser dev tools could edit their
// own balance directly in Firestore calls. Now the browser only ever
// SENDS A REQUEST ("I want to deposit Rs 500" / "approve this tx"); this
// function is the only thing that actually reads/writes balance fields,
// after verifying who is asking.
//
// Auth model:
//   - Every request must include a Firebase ID token (`idToken`) for the
//     calling user, obtained client-side via getIdToken().
//   - We verify that token using Identity Toolkit's accounts:lookup REST
//     endpoint (no firebase-admin npm package needed).
//   - Actions that should only ever be performed by the calling user
//     themselves (submit_deposit, submit_withdraw) are scoped to the
//     verified token's own email — a user can never submit on behalf of
//     someone else's email.
//   - Admin-only actions (approve/reject deposit & withdraw) additionally
//     check that the verified email matches OWNER_EMAIL.

const crypto = require('crypto');

const PROJECT_ID = process.env.FIREBASE_PROJECT_ID;
const CLIENT_EMAIL = process.env.FIREBASE_CLIENT_EMAIL;
const OWNER_EMAIL = (process.env.OWNER_EMAIL || 'abdullah.akmal5622@gmail.com').toLowerCase();
const FIREBASE_WEB_API_KEY = process.env.FIREBASE_WEB_API_KEY; // from Firebase console > Project settings > General > Web API Key

const MIN_DEPOSIT = 100;
const MIN_WITHDRAW = 200;
const WITHDRAW_FEE_RATE = 0.05;
const REFERRAL_FIRST_DEPOSIT_THRESHOLD = 100;
const REFERRAL_FIRST_DEPOSIT_BONUS = 10;
const REFERRAL_TEAM_QUALIFY_DEPOSIT = 150;
const REFERRAL_TEAM_MILESTONE_SIZE = 15;
const REFERRAL_TEAM_MILESTONE_BONUS = 50;

function getPrivateKey() {
  let key = process.env.FIREBASE_PRIVATE_KEY || '';
  key = key.trim();
  if ((key.startsWith('"') && key.endsWith('"')) || (key.startsWith("'") && key.endsWith("'"))) {
    key = key.slice(1, -1);
  }
  return key.replace(/\\n/g, '\n').replace(/\r\n/g, '\n');
}
const PRIVATE_KEY = getPrivateKey();

async function getAccessToken() {
  const header = { alg: 'RS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const claimSet = {
    iss: CLIENT_EMAIL,
    scope: 'https://www.googleapis.com/auth/datastore',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now
  };
  const base64url = (obj) =>
    Buffer.from(JSON.stringify(obj)).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unsigned = `${base64url(header)}.${base64url(claimSet)}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(unsigned);
  signer.end();
  const signature = signer.sign(PRIVATE_KEY).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const jwt = `${unsigned}.${signature}`;
  const resp = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  });
  const data = await resp.json();
  if (!data.access_token) throw new Error('Failed to get access token: ' + JSON.stringify(data));
  return data.access_token;
}

// Verifies a Firebase Auth ID token via the Identity Toolkit REST API and
// returns the verified email — does NOT trust any email the client sends.
async function verifyIdToken(idToken) {
  if (!idToken) return null;
  if (!FIREBASE_WEB_API_KEY) throw new Error('Server misconfigured: FIREBASE_WEB_API_KEY not set');
  const resp = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${FIREBASE_WEB_API_KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ idToken })
  });
  const data = await resp.json();
  if (data.error || !data.users || !data.users[0]) return null;
  return data.users[0].email.toLowerCase();
}

// ── Firestore REST helpers (no firebase-admin package needed) ──
function encodeValue(v) {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === 'string') return { stringValue: v };
  if (typeof v === 'boolean') return { booleanValue: v };
  if (typeof v === 'number') return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(encodeValue) } };
  if (typeof v === 'object') return { mapValue: { fields: encodeFields(v) } };
  return { stringValue: String(v) };
}
function encodeFields(obj) {
  const fields = {};
  for (const k in obj) fields[k] = encodeValue(obj[k]);
  return fields;
}
function decodeValue(v) {
  if (!v) return null;
  if ('stringValue' in v) return v.stringValue;
  if ('integerValue' in v) return parseInt(v.integerValue, 10);
  if ('doubleValue' in v) return v.doubleValue;
  if ('booleanValue' in v) return v.booleanValue;
  if ('nullValue' in v) return null;
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(decodeValue);
  if ('mapValue' in v) return decodeFields(v.mapValue.fields || {});
  return null;
}
function decodeFields(fields) {
  const obj = {};
  for (const k in fields) obj[k] = decodeValue(fields[k]);
  return obj;
}

// IMPORTANT: the client (index.html) saves user docs with doc ID =
// email.replace(/\./g,'_') — e.g. "name@gmail.com" -> "name@gmail_com".
// We must use the exact same scheme here, or every read/write in this
// file silently misses the real document (creating a duplicate doc
// instead of updating the user's actual balance).
function userDocId(email) {
  return email.replace(/\./g, '_');
}

async function getUserDoc(token, email) {
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents/pp_users/${encodeURIComponent(userDocId(email))}`;
  const resp = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
  if (resp.status === 404) return null;
  const data = await resp.json();
  if (data.error) throw new Error(data.error.message || 'Failed to read user');
  return decodeFields(data.fields || {});
}

async function setUserDoc(token, email, userObj) {
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents/pp_users/${encodeURIComponent(userDocId(email))}`;
  const resp = await fetch(url, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify({ fields: encodeFields(userObj) })
  });
  const data = await resp.json();
  if (data.error) throw new Error(data.error.message || 'Failed to write user');
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
}
function getDateTime() {
  return new Date().toISOString();
}

function jsonResp(statusCode, body) {
  return { statusCode, body: JSON.stringify(body) };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return jsonResp(405, { error: 'Method not allowed' });

  if (!PROJECT_ID || !CLIENT_EMAIL || !PRIVATE_KEY) {
    return jsonResp(500, { error: 'Missing Firebase service account environment variables on the server.' });
  }

  let payload;
  try { payload = JSON.parse(event.body || '{}'); } catch (e) { return jsonResp(400, { error: 'Invalid JSON body' }); }

  const { action, idToken } = payload;
  if (!action) return jsonResp(400, { error: 'Missing action' });

  let callerEmail;
  try {
    callerEmail = await verifyIdToken(idToken);
  } catch (e) {
    return jsonResp(500, { error: 'Token verification failed: ' + e.message });
  }
  if (!callerEmail) return jsonResp(401, { error: 'Invalid or expired session — please log in again' });

  const isAdminCaller = callerEmail === OWNER_EMAIL;

  try {
    const firestoreToken = await getAccessToken();

    // ── USER ACTION: submit a deposit request ──
    if (action === 'submit_deposit') {
      const { method, amount, accountNumber, accountName, receiptImage } = payload;
      if (!accountNumber || !accountName) return jsonResp(400, { error: 'Please fill all fields' });
      if (!amount || amount <= 0) return jsonResp(400, { error: 'Please enter a valid amount' });
      if (amount < MIN_DEPOSIT) return jsonResp(400, { error: `Minimum deposit is Rs ${MIN_DEPOSIT}` });
      if (!receiptImage) return jsonResp(400, { error: 'Please upload your payment receipt screenshot' });

      const u = await getUserDoc(firestoreToken, callerEmail);
      if (!u) return jsonResp(404, { error: 'Account not found' });

      const tx = {
        id: uid(), type: 'deposit', method, amount,
        accountNumber, accountName, date: getDateTime(), status: 'pending', receiptImage
      };
      u.transactions = u.transactions || [];
      u.transactions.unshift(tx);
      await setUserDoc(firestoreToken, callerEmail, u);
      return jsonResp(200, { status: 'ok', transactions: u.transactions });
    }

    // ── USER ACTION: submit a withdrawal request (holds the amount immediately) ──
    if (action === 'submit_withdraw') {
      const { method, amount, accountNumber, accountName } = payload;
      if (!accountNumber || !accountName) return jsonResp(400, { error: 'Please fill all fields' });
      if (!amount || amount <= 0) return jsonResp(400, { error: 'Please enter a valid amount' });
      if (amount < MIN_WITHDRAW) return jsonResp(400, { error: `Minimum withdrawal is Rs ${MIN_WITHDRAW}` });

      const u = await getUserDoc(firestoreToken, callerEmail);
      if (!u) return jsonResp(404, { error: 'Account not found' });
      if (amount > (u.balance || 0)) return jsonResp(400, { error: 'Insufficient balance' });

      const fee = parseFloat((amount * WITHDRAW_FEE_RATE).toFixed(2));
      const netAmount = parseFloat((amount - fee).toFixed(2));
      const tx = {
        id: uid(), type: 'withdraw', method, amount, fee, netAmount,
        accountNumber, accountName, date: getDateTime(), status: 'pending'
      };
      u.transactions = u.transactions || [];
      u.transactions.unshift(tx);
      u.balance = (u.balance || 0) - amount; // hold while pending
      await setUserDoc(firestoreToken, callerEmail, u);
      return jsonResp(200, { status: 'ok', balance: u.balance, transactions: u.transactions });
    }

    // ── Everything below is admin-only ──
    if (!isAdminCaller) return jsonResp(403, { error: 'Admin access required' });

    const { email, txId } = payload;
    if (!email || !txId) return jsonResp(400, { error: 'Missing email or txId' });

    if (action === 'approve_deposit') {
      const u = await getUserDoc(firestoreToken, email);
      if (!u) return jsonResp(404, { error: 'User not found' });
      const tx = (u.transactions || []).find(t => t.id === txId);
      if (!tx) return jsonResp(404, { error: 'Transaction not found' });
      if (tx.status !== 'pending') return jsonResp(409, { error: 'Transaction already processed' });

      tx.status = 'confirmed';
      const isFirstDeposit = (u.totalDeposit || 0) === 0;
      u.totalDeposit = (u.totalDeposit || 0) + tx.amount;
      u.balance = (u.balance || 0) + tx.amount;
      await setUserDoc(firestoreToken, email, u);

      // Referral bonuses
      if (u.referredBy) {
        const referrer = await getUserDoc(firestoreToken, u.referredBy);
        if (referrer) {
          let referrerChanged = false;
          if (isFirstDeposit && tx.amount >= REFERRAL_FIRST_DEPOSIT_THRESHOLD && !u.firstDepositBonusPaid) {
            referrer.balance = (referrer.balance || 0) + REFERRAL_FIRST_DEPOSIT_BONUS;
            referrer.transactions = referrer.transactions || [];
            referrer.transactions.unshift({
              id: uid(), type: 'referral_bonus', amount: REFERRAL_FIRST_DEPOSIT_BONUS,
              note: `${u.name} made their first deposit`, date: getDateTime(), status: 'confirmed'
            });
            u.firstDepositBonusPaid = true;
            referrerChanged = true;
          }

          const referrerReferralEmails = (referrer.referrals || []).map(r => r.email);
          let qualifiedCount = 0;
          for (const refEmail of referrerReferralEmails) {
            const refUser = refEmail === email ? u : await getUserDoc(firestoreToken, refEmail);
            if (refUser && (refUser.totalDeposit || 0) >= REFERRAL_TEAM_QUALIFY_DEPOSIT) qualifiedCount++;
          }
          const milestonesEarned = Math.floor(qualifiedCount / REFERRAL_TEAM_MILESTONE_SIZE);
          const milestonesAlreadyPaid = referrer.referralMilestonesReached || 0;
          if (milestonesEarned > milestonesAlreadyPaid) {
            const newMilestones = milestonesEarned - milestonesAlreadyPaid;
            const bonusAmount = newMilestones * REFERRAL_TEAM_MILESTONE_BONUS;
            referrer.balance = (referrer.balance || 0) + bonusAmount;
            referrer.transactions = referrer.transactions || [];
            for (let i = 0; i < newMilestones; i++) {
              const milestoneNum = (milestonesAlreadyPaid + i + 1) * REFERRAL_TEAM_MILESTONE_SIZE;
              referrer.transactions.unshift({
                id: uid(), type: 'referral_team_bonus', amount: REFERRAL_TEAM_MILESTONE_BONUS,
                note: `${milestoneNum} qualified team members`, date: getDateTime(), status: 'confirmed'
              });
            }
            referrer.referralMilestonesReached = milestonesEarned;
            referrerChanged = true;
          }

          if (referrerChanged) await setUserDoc(firestoreToken, u.referredBy, referrer);
          await setUserDoc(firestoreToken, email, u); // persist firstDepositBonusPaid flag
        }
      }

      return jsonResp(200, { status: 'ok' });
    }

    if (action === 'reject_deposit') {
      const u = await getUserDoc(firestoreToken, email);
      if (!u) return jsonResp(404, { error: 'User not found' });
      const tx = (u.transactions || []).find(t => t.id === txId);
      if (!tx) return jsonResp(404, { error: 'Transaction not found' });
      if (tx.status !== 'pending') return jsonResp(409, { error: 'Transaction already processed' });
      tx.status = 'rejected';
      await setUserDoc(firestoreToken, email, u);
      return jsonResp(200, { status: 'ok' });
    }

    if (action === 'approve_withdraw') {
      const u = await getUserDoc(firestoreToken, email);
      if (!u) return jsonResp(404, { error: 'User not found' });
      const tx = (u.transactions || []).find(t => t.id === txId);
      if (!tx) return jsonResp(404, { error: 'Transaction not found' });
      if (tx.status !== 'pending') return jsonResp(409, { error: 'Transaction already processed' });
      tx.status = 'confirmed';
      u.totalWithdrawn = (u.totalWithdrawn || 0) + tx.amount;
      await setUserDoc(firestoreToken, email, u);
      return jsonResp(200, { status: 'ok' });
    }

    if (action === 'reject_withdraw') {
      const u = await getUserDoc(firestoreToken, email);
      if (!u) return jsonResp(404, { error: 'User not found' });
      const tx = (u.transactions || []).find(t => t.id === txId);
      if (!tx) return jsonResp(404, { error: 'Transaction not found' });
      if (tx.status !== 'pending') return jsonResp(409, { error: 'Transaction already processed' });
      tx.status = 'rejected';
      u.balance = (u.balance || 0) + tx.amount; // refund the held amount
      await setUserDoc(firestoreToken, email, u);
      return jsonResp(200, { status: 'ok' });
    }

    // ── USER ACTION: join Mega Contest (PP or Dream11) ──
    // payload: { action, idToken, matchId, contestType:'pp'|'d11', entryFee }
    if (action === 'join_mega_contest') {
      const { matchId, contestType, entryFee } = payload;
      if (!matchId || !entryFee || entryFee <= 0) return jsonResp(400, { error: 'Missing matchId or entryFee' });

      const u = await getUserDoc(firestoreToken, callerEmail);
      if (!u) return jsonResp(404, { error: 'Account not found' });
      if ((u.balance || 0) < entryFee) return jsonResp(400, { error: `Insufficient balance. Need Rs ${entryFee}` });

      const txType = contestType === 'd11' ? 'd11_mega_entry' : 'mega_entry';
      u.balance = (u.balance || 0) - entryFee;
      u.transactions = u.transactions || [];
      u.transactions.unshift({ id: uid(), type: txType, amount: entryFee, matchId, date: getDateTime(), status: 'confirmed' });
      await setUserDoc(firestoreToken, callerEmail, u);
      return jsonResp(200, { status: 'ok', balance: u.balance, transactions: u.transactions });
    }

    // ── USER ACTION: create or join a custom contest ──
    // payload: { action, idToken, matchId, entryFee, contestCode (for join only) }
    if (action === 'create_custom_contest' || action === 'join_custom_contest') {
      const { matchId, entryFee, contestCode } = payload;
      if (!matchId || !entryFee || entryFee <= 0) return jsonResp(400, { error: 'Missing matchId or entryFee' });

      const u = await getUserDoc(firestoreToken, callerEmail);
      if (!u) return jsonResp(404, { error: 'Account not found' });
      if ((u.balance || 0) < entryFee) return jsonResp(400, { error: `You need Rs ${entryFee} balance to join this contest` });

      u.balance = (u.balance || 0) - entryFee;
      u.transactions = u.transactions || [];
      u.transactions.unshift({
        id: uid(), type: 'custom_entry', amount: entryFee,
        matchId, contestCode: contestCode || null, date: getDateTime(), status: 'confirmed'
      });
      await setUserDoc(firestoreToken, callerEmail, u);
      return jsonResp(200, { status: 'ok', balance: u.balance, transactions: u.transactions });
    }

    // ── USER ACTION: join H2H contest ──
    // payload: { action, idToken, matchId, entryFee }
    if (action === 'join_h2h') {
      const { matchId, entryFee } = payload;
      if (!matchId || !entryFee || entryFee <= 0) return jsonResp(400, { error: 'Missing matchId or entryFee' });

      const u = await getUserDoc(firestoreToken, callerEmail);
      if (!u) return jsonResp(404, { error: 'Account not found' });
      if ((u.balance || 0) < entryFee) return jsonResp(400, { error: `Minimum Rs ${entryFee} balance required to join H2H Contest` });

      u.balance = (u.balance || 0) - entryFee;
      u.transactions = u.transactions || [];
      u.transactions.unshift({ id: uid(), type: 'h2h_entry', amount: entryFee, matchId, date: getDateTime(), status: 'confirmed' });
      await setUserDoc(firestoreToken, callerEmail, u);
      return jsonResp(200, { status: 'ok', balance: u.balance, transactions: u.transactions });
    }

    // ── ADMIN ACTION: credit prize to a winner (contest/H2H settlement) ──
    // payload: { action, idToken, email, amount, txType, matchId, note }
    if (action === 'credit_prize') {
      if (!isAdminCaller) return jsonResp(403, { error: 'Admin access required' });
      const { email: targetEmail, amount, txType, matchId, note } = payload;
      if (!targetEmail || !amount || amount <= 0) return jsonResp(400, { error: 'Missing email or amount' });

      const u = await getUserDoc(firestoreToken, targetEmail);
      if (!u) return jsonResp(404, { error: 'User not found' });
      u.balance = (u.balance || 0) + amount;
      u.transactions = u.transactions || [];
      u.transactions.unshift({
        id: uid(), type: txType || 'prize', amount,
        matchId: matchId || null, note: note || null,
        date: getDateTime(), status: 'confirmed'
      });
      await setUserDoc(firestoreToken, targetEmail, u);
      return jsonResp(200, { status: 'ok', balance: u.balance });
    }

    // ── ADMIN ACTION: refund entry fee (cancelled H2H, lone player, etc.) ──
    // payload: { action, idToken, email, amount, matchId, note }
    if (action === 'refund_entry') {
      if (!isAdminCaller) return jsonResp(403, { error: 'Admin access required' });
      const { email: targetEmail, amount, matchId, note } = payload;
      if (!targetEmail || !amount || amount <= 0) return jsonResp(400, { error: 'Missing email or amount' });

      const u = await getUserDoc(firestoreToken, targetEmail);
      if (!u) return jsonResp(404, { error: 'User not found' });
      u.balance = (u.balance || 0) + amount;
      u.transactions = u.transactions || [];
      u.transactions.unshift({
        id: uid(), type: 'refund', amount,
        matchId: matchId || null, note: note || null,
        date: getDateTime(), status: 'confirmed'
      });
      await setUserDoc(firestoreToken, targetEmail, u);
      return jsonResp(200, { status: 'ok', balance: u.balance });
    }

    return jsonResp(400, { error: 'Unknown action' });
  } catch (err) {
    return jsonResp(500, { error: err.message });
  }
};
