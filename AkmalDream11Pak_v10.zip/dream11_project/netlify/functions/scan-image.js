// netlify/functions/scan-image.js
//
// Server-side proxy for the AI screenshot-scan features (squad screenshot
// scan + scorecard screenshot scan). This runs on Netlify's server, never in
// the browser, so the Gemini API key stays safe and is never exposed in any
// file that gets deployed or viewed in browser dev tools.
//
// The API key is read from an environment variable (set in Netlify dashboard
// → Site settings → Environment variables → GEMINI_API_KEY), NOT hardcoded.
//
// The browser sends: { prompt: "...", images: [{ data: "<base64>", mediaType: "image/jpeg" }, ...] }
// This function calls Gemini's generateContent REST API and returns: { text: "<model's raw text reply>" }

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_MODEL = 'gemini-2.5-flash'; // free-tier model, supports image input
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }
  if (!GEMINI_API_KEY) {
    return { statusCode: 500, body: JSON.stringify({ error: 'GEMINI_API_KEY is not configured on the server' }) };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const { prompt, images } = payload;
  if (!prompt || !Array.isArray(images) || images.length === 0) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Request must include "prompt" and a non-empty "images" array' }) };
  }

  // Build Gemini "parts": one text part + one inlineData part per image
  const parts = [{ text: prompt }];
  images.forEach(img => {
    if (img && img.data) {
      parts.push({ inlineData: { mimeType: img.mediaType || 'image/jpeg', data: img.data } });
    }
  });

  try {
    const response = await fetch(GEMINI_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': GEMINI_API_KEY
      },
      body: JSON.stringify({
        contents: [{ role: 'user', parts }],
        generationConfig: { maxOutputTokens: 8000 }
      })
    });

    const data = await response.json();

    if (!response.ok) {
      const message = (data && data.error && data.error.message) || `Gemini API error ${response.status}`;
      return { statusCode: response.status, body: JSON.stringify({ error: message }) };
    }

    const candidate = (data.candidates || [])[0];
    const textPart = candidate && candidate.content && (candidate.content.parts || []).find(p => typeof p.text === 'string');

    if (!textPart) {
      return { statusCode: 502, body: JSON.stringify({ error: 'No text in Gemini response' }) };
    }

    return { statusCode: 200, body: JSON.stringify({ text: textPart.text }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: 'Failed to reach Gemini API: ' + err.message }) };
  }
};
