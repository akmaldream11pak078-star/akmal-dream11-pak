// netlify/functions/admin-set-password.js
//
// Runs on Netlify's server only (never in the browser).
// Requires a valid, unexpired OTP (sent via send-otp.js) before it will
// touch any account — this proves the caller actually owns the email
// address, preventing anyone who merely knows a user's email from
// resetting their password.
//
// Uses the Firebase service account to get an OAuth token, then calls the
// Identity Toolkit Admin REST API to either:
//   - create a Firebase Auth account for a given email/password (migration), or
//   - forcibly set/reset the password for an EXISTING Firebase Auth account.

const crypto = require('crypto');

const PROJECT_ID = process.env.FIREBASE_PROJECT_ID;
const CLIENT_EMAIL = process.env.FIREBASE_CLIENT_EMAIL;

function getPrivateKey() {
  let key = process.env.FIREBASE_PRIVATE_KEY || '';
  key = key.trim();
  if (
    (key.startsWith('"') && key.endsWith('"')) ||
    (key.startsWith("'") && key.endsWith("'"))
  ) {
    key = key.slice(1, -1);
  }
  key = key.replace(/\\n/g, '\n');
  key = key.replace(/\r\n/g, '\n');
  return key;
}

const PRIVATE_KEY = getPrivateKey();

async function getAccessToken(scope) {
  const header = { alg: 'RS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const claimSet = {
    iss: CLIENT_EMAIL,
    scope,
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now
  };

  const base64url = (obj) =>
    Buffer.from(JSON.stringify(obj)).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

  const unsigned = `${base64url(header)}.${base64url(claimSet)}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(unsigned);
  signer.end();
  const signature = signer.sign(PRIVATE_KEY).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

  const jwt = `${unsigned}.${signature}`;

  const resp = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  });

  const data = await resp.json();
  if (!data.access_token) {
    throw new Error('Failed to get access token: ' + JSON.stringify(data));
  }
  return data.access_token;
}

// Looks up whether a Firebase Auth account already exists for this email.
async function lookupAccount(accessToken, email) {
  const resp = await fetch(
    `https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts:lookup`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` },
      body: JSON.stringify({ email: [email] })
    }
  );
  const data = await resp.json();
  if (data.users && data.users.length > 0) return data.users[0];
  return null;
}

// Reads the OTP doc written by send-otp.js via Firestore REST, then deletes
// it on success so a single OTP can't be replayed.
async function verifyOtp(firestoreToken, email, otp) {
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents/pp_password_otps/${encodeURIComponent(email)}`;
  const resp = await fetch(url, { headers: { 'Authorization': `Bearer ${firestoreToken}` } });
  if (resp.status === 404) return { ok: false, reason: 'No verification code was requested for this email — please request a new one.' };
  const data = await resp.json();
  if (data.error) return { ok: false, reason: 'Could not verify code — please try again.' };

  const fields = data.fields || {};
  const expiresAt = parseInt(fields.expiresAt?.integerValue || '0', 10);
  const attempts = parseInt(fields.attempts?.integerValue || '0', 10);
  const storedHash = fields.otpHash?.stringValue || '';

  if (attempts >= 5) return { ok: false, reason: 'Too many incorrect attempts — please request a new code.' };
  if (Date.now() > expiresAt) return { ok: false, reason: 'This code has expired — please request a new one.' };

  const otpHash = crypto.createHash('sha256').update(String(otp)).digest('hex');
  if (otpHash !== storedHash) {
    // Increment attempts so brute-forcing the 6-digit code is rate-limited
    await fetch(url, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${firestoreToken}` },
      body: JSON.stringify({ fields: { ...fields, attempts: { integerValue: String(attempts + 1) } } })
    });
    return { ok: false, reason: 'Incorrect verification code.' };
  }

  // Success — delete the OTP doc so it can't be reused
  await fetch(url, { method: 'DELETE', headers: { 'Authorization': `Bearer ${firestoreToken}` } });
  return { ok: true };
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  if (!PROJECT_ID || !CLIENT_EMAIL || !PRIVATE_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Missing Firebase service account environment variables on the server.' })
    };
  }

  try {
    const { email, newPassword, otp } = JSON.parse(event.body || '{}');

    if (!email || !newPassword || newPassword.length < 6) {
      return { statusCode: 400, body: JSON.stringify({ error: 'A valid email and a newPassword (6+ chars) are required.' }) };
    }
    if (!otp) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Verification code is required.' }) };
    }

    const cleanEmail = email.toLowerCase().trim();
    const firestoreToken = await getAccessToken('https://www.googleapis.com/auth/datastore');

    const otpResult = await verifyOtp(firestoreToken, cleanEmail, otp);
    if (!otpResult.ok) {
      return { statusCode: 401, body: JSON.stringify({ error: otpResult.reason }) };
    }

    const identityToken = await getAccessToken('https://www.googleapis.com/auth/identitytoolkit https://www.googleapis.com/auth/firebase');
    const existing = await lookupAccount(identityToken, cleanEmail);

    if (existing && existing.localId) {
      const resp = await fetch(
        `https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts:update`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${identityToken}` },
          body: JSON.stringify({ localId: existing.localId, password: newPassword })
        }
      );
      const data = await resp.json();
      if (data.error) {
        return { statusCode: 500, body: JSON.stringify({ error: data.error.message || 'Failed to update password' }) };
      }
      return { statusCode: 200, body: JSON.stringify({ status: 'password_updated' }) };
    } else {
      const resp = await fetch(
        `https://identitytoolkit.googleapis.com/v1/projects/${PROJECT_ID}/accounts`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${identityToken}` },
          body: JSON.stringify({ email: cleanEmail, password: newPassword })
        }
      );
      const data = await resp.json();
      if (data.error) {
        return { statusCode: 500, body: JSON.stringify({ error: data.error.message || 'Failed to create account' }) };
      }
      return { statusCode: 200, body: JSON.stringify({ status: 'account_created' }) };
    }
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};

