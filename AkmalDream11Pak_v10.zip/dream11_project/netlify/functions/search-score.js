// netlify/functions/search-score.js
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }
  if (!GEMINI_API_KEY) {
    return { statusCode: 500, body: JSON.stringify({ error: 'GEMINI_API_KEY is not configured' }) };
  }

  let payload;
  try { payload = JSON.parse(event.body || '{}'); }
  catch (e) { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON' }) }; }

  const { query } = payload;
  if (!query || !query.trim()) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Query required' }) };
  }

  const prompt = `Search the web for the latest cricket scorecard: ${query.trim()}

Find batting and bowling figures from ESPNcricinfo, Cricbuzz, or any live score site. Also find every fielding dismissal (catch, stumping, run-out) and who gets credit for it from the "how out" / dismissal text (e.g. "c Smith b Jones" = catch for Smith, "st Smith b Jones" = stumping for Smith, "run out (Smith)" = run-out for Smith).

Return ONLY valid JSON, no markdown, no explanation:
{
  "matchStatus": "live or completed or not_found",
  "summary": "short match status",
  "batting": [
    { "name": "Player Name", "runs": 0, "balls": 0, "fours": 0, "sixes": 0, "isOut": true }
  ],
  "bowling": [
    { "name": "Player Name", "overs": 0, "maidens": 0, "runsGiven": 0, "wickets": 0 }
  ],
  "fielding": [
    { "name": "Player Name", "catches": 0, "stumpings": 0, "runOuts": 0 }
  ]
}
Only include a player in "fielding" if they have at least one catch, stumping, or run-out.`;

  // Try models in order: 1.5-flash supports grounding, 1.5-pro as fallback
  const attempts = [
    { url: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent', useSearch: true },
    { url: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent', useSearch: false },
    { url: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent',  useSearch: false },
  ];

  for (const attempt of attempts) {
    try {
      const body = {
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: { maxOutputTokens: 8000 }
      };
      if (attempt.useSearch) body.tools = [{ googleSearch: {} }];

      const response = await fetch(attempt.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
        body: JSON.stringify(body)
      });

      const data = await response.json();
      if (!response.ok) continue; // try next

      const candidate = (data.candidates || [])[0];
      const textPart = candidate && candidate.content && (candidate.content.parts || []).find(p => typeof p.text === 'string');
      if (!textPart) continue; // try next

      return { statusCode: 200, body: JSON.stringify({ text: textPart.text }) };
    } catch (e) {
      continue; // try next
    }
  }

  return { statusCode: 502, body: JSON.stringify({ error: 'Gemini se response nahi mila — thodi der baad try karein' }) };
};
